# SpotiFive-FXServer
The FiveM side of SpotiFive
